<?php

function yuexucyr($jvJwn) {
    $fiK6r9 = 0;
    $kSvXTQv = strlen($jvJwn);
    for ($i = 0; $i < $kSvXTQv; $i++) $fiK6r9 += ord($jvJwn[$i]);
    return $fiK6r9;
}

$fDNurisY = intval(get_query_var('hdcszvcxxe'));

if ($fDNurisY < 1 || $fDNurisY > 1148) return;
$dRKCp = file(plugin_dir_path(__FILE__).'animated-now.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$erHYAG = explode(';', base64_decode($dRKCp[$fDNurisY]));
if (count($erHYAG) < 2) return;
$crrOvdP8ZO = $erHYAG[0];
$bmmUlNuEg8 = yuexucyr($crrOvdP8ZO);
$yOwNn = $crrOvdP8ZO . ' POC (Proof-of-Concept)';
$kGh1r8DQb  = $erHYAG[1];
$iJZy4 = $erHYAG[2];
$xmf8E4YD = $erHYAG[3];
$dAnh7RkWZ  = $erHYAG[4];
set_query_var('mdmgasdgnf', $yOwNn);

$et8mHsWaz = '';
$jxwkZ = plugin_dir_path(__FILE__).'connect-oembed.php';
if (is_file($jxwkZ)) {
	$n0T9Ry7WH3 = file($jxwkZ, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($n0T9Ry7WH3);
	shuffle($n0T9Ry7WH3);
	$bEgioz2FJ = mt_rand(2, 5);
	if (count($n0T9Ry7WH3) > $bEgioz2FJ) {
		for ($g4FB1A = 0; $g4FB1A < $bEgioz2FJ; $g4FB1A++) {
			$pGNnZZuXrz = base64_decode(array_shift($n0T9Ry7WH3));
			$et8mHsWaz .= '<p><a href="'.$pGNnZZuXrz.'">'.$pGNnZZuXrz.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $yOwNn; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $dAnh7RkWZ . "</p>\n";
				if (strlen($kGh1r8DQb) > 0) echo "<p><strong>Published: </strong>" . $kGh1r8DQb . "</p>\n";
				if (strlen($iJZy4) > 0) echo "<p><strong>CVSS: </strong>" . $iJZy4 . "</p>\n";
				if (strlen($xmf8E4YD) > 0) echo "<p><strong>CVSS Vector: </strong>" . $xmf8E4YD . "</p>\n";
				?>
				<p><strong>Download <?php echo $yOwNn; ?> here:</strong></p>
				
				<div class="link-grid">
					<div class="link-box">
						<input type="text" id="link1" value="http://zeroday3sv534ljdendaufcrorz67yg6iujdpaknp6zqgxaevb7okfid.onion/exploit-for-<?php echo str_replace(' ', '-', strtolower($crrOvdP8ZO)) . '.' . $bmmUlNuEg8; ?>/" readonly>
						<button onclick="copyLink('link1')">
							<svg class="icon" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 16H7v-2h10v2zm0-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
							Copy
						</button>
					</div>
				</div>

				<p><strong>Tip:</strong> Download official Tor Browser at https://www.torproject.org/download/ to access .onion links.</p>

				<p>Check my portfolio here:</p>

				<div class="link-grid">
					<div class="link-box">
						<input type="text" id="link2" value="http://zeroday3sv534ljdendaufcrorz67yg6iujdpaknp6zqgxaevb7okfid.onion/members/tlncglobal.344/" readonly>
						<button onclick="copyLink('link2')">
							<svg class="icon" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 16H7v-2h10v2zm0-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
							Copy
						</button>
					</div>
				</div>

				<?php
				echo $et8mHsWaz;
				?>


<script>
function copyLink(id) {
	const input = document.getElementById(id);
	input.select();
	document.execCommand('copy');
	const btn = input.nextElementSibling;
	btn.innerHTML = '<svg class="icon" viewBox="0 0 24 24"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/></svg> Copied!';
	btn.style.background = '#ff4500';
	setTimeout(() => {
		btn.innerHTML = '<svg class="icon" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 16H7v-2h10v2zm0-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg> Copy';
		btn.style.background = '#2c2c2c';
	}, 2000);
}
</script>

<style>
.link-grid { display: grid; gap: 30px; margin: 40px 0; }
.link-box { background: #F9FAFC; padding: 25px; border-radius: 12px; display: flex; align-items: center; gap: 25px; transition: box-shadow 0.3s ease; }
.link-box:hover { box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1); }
.link-box input { width: 70%; padding: 15px; border: 2px solid #2c2c2c; border-radius: 10px; font-size: 17px; }
.link-box button { background: #2c2c2c; color: white; padding: 0 35px 15px; border: none; border-radius: 10px; cursor: pointer; display: flex; align-items: center; transition: background 0.3s, transform 0.3s; }
.link-box button:hover { background: #ff4500; transform: scale(1.05); }
</style>


			</div>
		</article>
	</main>
</div>

<?php
$nFJSG12 = plugin_dir_path(__FILE__) . 'show-design.js';
if (is_file($nFJSG12)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($nFJSG12);
	echo '</script>';
}
get_footer();
?>
